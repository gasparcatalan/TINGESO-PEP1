package com.example.PEP1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Pep1Application {

	public static void main(String[] args) {
		SpringApplication.run(Pep1Application.class, args);
	}

}
