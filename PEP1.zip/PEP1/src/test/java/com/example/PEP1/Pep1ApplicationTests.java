package com.example.PEP1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Pep1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
